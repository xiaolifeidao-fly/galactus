## 从有钱获取任务提交
```
cd order
python3 submit_order.py 
```



## collection_device 搜集设备

### 安装依赖
```
cd collection_device
pnpm install
```

### 开发
```
pnpm run dev
```

### 打包 & 运行
```
pnpm run build
pnpm run start
```